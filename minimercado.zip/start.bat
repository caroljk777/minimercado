@echo on
gcc -o src/output/mercado.exe src/main.c src/functions/inventory.c
if %errorlevel% neq 0 exit /b %errorlevel%
.\src\output\mercado.exe
pause
