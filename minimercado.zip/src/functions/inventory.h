#ifndef INVENTORY_H
#define INVENTORY_H

#include <time.h>

#define MAXIMOPRODUTOS 100
#define ALERTASTOCK 10
#define FIMVALIDADE 15
#define FILENAME "src/produtos.txt"

typedef struct
{
  char nome[100];
  int quantidade;
  struct tm fimValidade;
} Product;

void guardarProdutosFile();
void processarProdutosFile();
void addProdutos();
void verInventario();
void venderProdutos();

#endif // INVENTORY_H
