#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "inventory.h"

Product products[MAXIMOPRODUTOS];
int product_count = 0;

void guardarProdutosFile() // salvar os produtos no arquivo
{
  FILE *file = fopen(FILENAME, "w");
  if (file == NULL)
  {
    perror("Erro ao abrir o ficheiro");
    return;
  }

  for (int i = 0; i < product_count; i++)
  {
    fprintf(file, " _______                         \n");
    fprintf(file, "(_______)   _                    \n");
    fprintf(file, " _____ ____| |_ _   _  ____ ____ \n");
    fprintf(file, "|  ___) _  |  _) | | |/ ___) _  |\n");
    fprintf(file, "| |  ( ( | | |_| |_| | |  ( ( | |\n");
    fprintf(file, "|_|   \\_||_|\\___)____|_|   \\_||_|\n");
    fprintf(file, "                                 \n");

    fprintf(file, "produto: %s \n", products[i].nome);
    fprintf(file, "quantidade disponivel: %d\n", products[i].quantidade);
    fprintf(file, "data de validade: %02d.%02d.%d\n", products[i].fimValidade.tm_mday, products[i].fimValidade.tm_mon + 1, products[i].fimValidade.tm_year + 1900);
  }

  fclose(file);
}

void processarProdutosFile() // carreagar os produtos no arquivo
{
  FILE *file = fopen(FILENAME, "r");
  if (file == NULL)
  {
    perror("Erro ao abrir o ficheiro");
    return;
  }

  product_count = 0;
  while (fscanf(file, "%s %d %d.%d.%d", products[product_count].nome, &products[product_count].quantidade,
                &products[product_count].fimValidade.tm_mday, &products[product_count].fimValidade.tm_mon,
                &products[product_count].fimValidade.tm_year) != EOF)
  {
    products[product_count].fimValidade.tm_mon -= 1;
    products[product_count].fimValidade.tm_year -= 1900;
    product_count++;
  }

  fclose(file);
}

void addProdutos()
{
  if (product_count >= MAXIMOPRODUTOS)
  {
    printf("O seu armazenamento está cheio, não será preciso encomendar mais produtos\n");
    return;
  }

  printf("Nome do produto: ");
  scanf("%s", products[product_count].nome);

  printf("Quantidade: ");
  scanf("%d", &products[product_count].quantidade);

  printf("Validade (dd.mm.yyyy): ");
  int day, month, year;
  scanf("%d.%d.%d", &day, &month, &year);

  products[product_count].fimValidade.tm_mday = day;
  products[product_count].fimValidade.tm_mon = month - 1;
  products[product_count].fimValidade.tm_year = year - 1900;

  product_count++;
  guardarProdutosFile();
}

void check_inventory()
{
  time_t now = time(NULL);
  struct tm *current_time = localtime(&now);

  printf("Current time: %s", asctime(current_time));

  for (int i = 0; i < product_count; i++)
  {
    if (products[i].quantidade <= ALERTASTOCK)
    {
      printf("ALERTA: Só há %d unidades de %s. Encomende mais!\n", products[i].quantidade, products[i].nome);
    }

    struct tm expiry_time = products[i].fimValidade;
    time_t fimValidade_time = mktime(&expiry_time);

    double seconds = difftime(fimValidade_time, now);
    int days = (int)(seconds / (60 * 60 * 24));

    if (days <= FIMVALIDADE)
    {
      printf("ALERTA: O prazo de validade de %s está próximo (%02d.%02d.%d). Recomenda-se aplicar desconto!\n",
             products[i].nome, products[i].fimValidade.tm_mday, products[i].fimValidade.tm_mon + 1,
             products[i].fimValidade.tm_year + 1900);
    }

    if (days == 15)
    {
      printf("ALERTA: O produto %s tem 15 dias restantes até o vencimento.\n", products[i].nome);
    }

    if (difftime(now, fimValidade_time) <= 0)
    {
      printf("O produto %s ainda está dentro do prazo de validade.\n", products[i].nome);
    }
    else
    {
      printf("ALERTA: O produto %s está fora do prazo de validade (%02d.%02d.%d).\n",
             products[i].nome, products[i].fimValidade.tm_mday, products[i].fimValidade.tm_mon + 1,
             products[i].fimValidade.tm_year + 1900);
    }
  }

  system("pause");
}

void venderProdutos()
{
  char nome[100];
  int quantidade;

  printf("Nome do produto vendido: ");
  scanf("%s", nome);

  printf("Quantidade vendida: ");
  scanf("%d", &quantidade);

  for (int i = 0; i < product_count; i++)
  {
    if (strcmp(products[i].nome, nome) == 0)
    {
      if (products[i].quantidade >= quantidade)
      {
        products[i].quantidade -= quantidade;
        printf("%d unidades de %s vendidas. Restam %d unidades.\n", quantidade, nome, products[i].quantidade);
        guardarProdutosFile();
        return;
      }
      else
      {
        printf("Quantidade insuficiente de %s. Disponível: %d unidades.\n", nome, products[i].quantidade);
        return;
      }
    }
  }

  printf("Produto %s não encontrado.\n", nome);
}
