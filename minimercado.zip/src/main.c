#include <stdio.h>
#include <stdlib.h>
#include <windows.h>

#include "./functions/inventory.h"
#include "components/header.c"

int main()
{
   processarProdutosFile();
  int choice;

  while (1)
  {
    system("chcp 65001");
    system("cls");

    header();
    printf("\nO seu mercado:\n");
    printf("1. Adicionar produto\n");
    printf("2. Vender produto\n");
    printf("3. Verificar inventário\n");
    printf("4. Sair\n");
    printf("Escolha uma opcao: \n");
    scanf("%d", &choice);
    system("cls");

    switch (choice)
    {
    case 1:
      system("cls");
      addProdutos();
      break;
    case 2:
      venderProdutos();
      break;
    case 3:
      verInventario();
      break;
    case 4:
      printf("A sair..\n");
      return 0;
    default:
      printf("Opção inválida! Tente novamente.\n");
    }
  }

  return 0;
}
